#!/bin/bash
# calculadora.sh
# Script exemplo em Bash que realiza operações básicas e grava resultado em resultado.txt
#
# Observação: usa aritmética inteira do shell (expr/bc pode ser usado para floats)

echo "Digite o primeiro número: "
read n1

echo "Digite o segundo número: "
read n2

echo "Escolha a operação:"
echo "1 - Soma"
echo "2 - Subtração"
echo "3 - Multiplicação"
echo "4 - Divisão"
read opcao

case $opcao in
    1) resultado=$((n1 + n2)) ;;
    2) resultado=$((n1 - n2)) ;;
    3) resultado=$((n1 * n2)) ;;
    4)
       if [ "$n2" -ne 0 ]; then
          resultado=$((n1 / n2))
       else
          echo "Erro: divisão por zero"
          exit 1
       fi
       ;;
    *) echo "Opção inválida"; exit 1 ;;
esac

echo "Soma/Subtração/Resultado: $resultado" > resultado.txt
echo "Resultado salvo em resultado.txt"
