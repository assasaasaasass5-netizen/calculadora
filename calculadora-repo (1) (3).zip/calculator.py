#!/usr/bin/env python3
# calculator.py
# Calculadora interativa em Python com menu e várias operações.

def get_numbers():
    """Pede dois números ao usuário e retorna como float."""
    while True:
        try:
            a = input("Digite o primeiro número (use '.' para decimal): ").strip()
            b = input("Digite o segundo número (use '.' para decimal): ").strip()
            a = float(a.replace(',', '.'))
            b = float(b.replace(',', '.'))
            return a, b
        except ValueError:
            print("Entrada inválida. Informe números (ex.: 10 ou 3.14). Tente novamente.\n")

def main():
    print("=== Calculadora — Projeto Inicial ===")
    a, b = get_numbers()
    print(f"Números registrados: a = {a}, b = {b}\n")

    while True:
        print("Escolha a operação:")
        print(" 1) Soma (a + b)")
        print(" 2) Subtração (a - b)")
        print(" 3) Multiplicação (a * b)")
        print(" 4) Divisão (a / b)")
        print(" 5) Resto (a % b)")
        print(" 6) Potência (a ** b)")
        print(" 7) Média ((a + b) / 2)")
        print(" 8) Trocar números")
        print(" 0) Sair")
        opc = input("Opção: ").strip()

        if opc == "0":
            print("Encerrando. Obrigado!")
            break
        elif opc == "1":
            resultado = a + b
            descricao = "Soma"
        elif opc == "2":
            resultado = a - b
            descricao = "Subtração"
        elif opc == "3":
            resultado = a * b
            descricao = "Multiplicação"
        elif opc == "4":
            try:
                resultado = a / b
                descricao = "Divisão"
            except ZeroDivisionError:
                print("Erro: divisão por zero. Escolha outra operação ou troque os números.\n")
                continue
        elif opc == "5":
            try:
                resultado = a % b
                descricao = "Resto"
            except ZeroDivisionError:
                print("Erro: resto por zero. Escolha outra operação ou troque os números.\n")
                continue
        elif opc == "6":
            resultado = a ** b
            descricao = "Potência"
        elif opc == "7":
            resultado = (a + b) / 2
            descricao = "Média"
        elif opc == "8":
            a, b = get_numbers()
            print(f"Números atualizados: a = {a}, b = {b}\n")
            continue
        else:
            print("Opção inválida. Tente novamente.\n")
            continue

        # Impressão do resultado (mostra inteiro quando o valor for inteiro)
        if abs(resultado - int(resultado)) < 1e-12:
            print(f"{descricao}: {int(resultado)}\n")
        else:
            print(f"{descricao}: {resultado}\n")

if __name__ == "__main__":
    main()
