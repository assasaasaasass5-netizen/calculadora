# Calculadora — Projeto Final

Repositório de exemplo contendo:

- `calculadora.sh` — script em Bash que pede dois números, executa uma operação básica e grava o resultado em `resultado.txt`.
- `calculator.py` — versão em Python com menu interativo e várias operações (soma, subtração, multiplicação, divisão, resto, potência, média).
- `numeros.txt` — arquivo de exemplo com dois números.
- `.gitignore` — itens sugeridos para ignorar.

## Instruções rápidas (executar localmente)

### Pré-requisitos
- Git instalado
- Python 3 instalado (para rodar `calculator.py`)
- Ambiente Linux / macOS (ou WSL no Windows)

### Rodar o script Bash (.sh)
1. Dê permissão de execução:
   ```bash
   chmod 744 calculadora.sh
   ```
2. Execute:
   ```bash
   ./calculadora.sh
   ```
3. O script pedirá dois números e uma operação; o resultado será gravado em `resultado.txt`.

Observação: o script usa aritmética inteira do shell. Para números com casas decimais, use a versão em Python ou adapte o script para `bc`.

### Rodar o script Python
1. Execute:
   ```bash
   python3 calculator.py
   ```
2. Siga o menu interativo. É possível trocar os números sem reiniciar o programa.

## Como hospedar no GitHub
1. Crie um repositório no GitHub (via site) com o nome que preferir.
2. No diretório local (onde estão os arquivos), inicialize o git e envie:
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/<SEU_USUARIO>/<SEU_REPO>.git
   git push -u origin main
   ```
3. Para garantir que o arquivo `.sh` permaneça executável ao clonar:
   ```bash
   chmod 744 calculadora.sh
   git add calculadora.sh
   git commit -m "Make calculadora.sh executable"
   git push
   ```

### Hospedar o executável como Release (opcional)
- Via web: vá em **Releases** no GitHub, **Draft a new release**, escolha tag (ex.: v1.0) e faça upload do `calculadora.sh` como artifact.
- Via `gh` (GitHub CLI):
  ```bash
  gh release create v1.0 calculadora.sh --title "v1.0" --notes "Release com calculadora.sh"
  ```
Observação: arquivos anexados a releases podem não preservar a flag de executável; após o download, rode `chmod +x calculadora.sh`.

## Explicação do código Python (`calculator.py`)
- `get_numbers()`:
  - Função que solicita ao usuário dois valores, valida e converte para `float`.
- `main()`:
  - Exibe o menu com opções de operação.
  - Permite ao usuário selecionar operações: soma, subtração, multiplicação, divisão, resto, potência e média.
  - Possui opção para trocar os números sem sair do programa.
  - Laço principal `while True` mantém o menu ativo até o usuário escolher sair.
  - Trata divisão por zero e entradas inválidas.

## Submissão
- Crie o repositório no GitHub e envie o link na sua entrega.

Tempo estimado: 40 minutos
